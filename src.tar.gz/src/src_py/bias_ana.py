# To convert the jobscript and adsfrac files for computing \Delta U

